<?php
class FtpGroupsController extends AppController {

	var $name = 'FtpGroups';

	function index() {
		$this->FtpGroup->recursive = 0;
		$this->set('ftpGroups', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid ftp group', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('ftpGroup', $this->FtpGroup->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->FtpGroup->create();
			if ($this->FtpGroup->save($this->data)) {
				$this->Session->setFlash(__('The ftp group has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The ftp group could not be saved. Please, try again.', true));
			}
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid ftp group', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->FtpGroup->save($this->data)) {
				$this->Session->setFlash(__('The ftp group has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The ftp group could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->FtpGroup->read(null, $id);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for ftp group', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->FtpGroup->delete($id)) {
			$this->Session->setFlash(__('Ftp group deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Ftp group was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	function admin_index() {
		$this->FtpGroup->recursive = 0;
		$this->set('ftpGroups', $this->paginate());
	}

	function admin_view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid ftp group', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('ftpGroup', $this->FtpGroup->read(null, $id));
	}

	function admin_add() {
		if (!empty($this->data)) {
			$this->FtpGroup->create();
			if ($this->FtpGroup->save($this->data)) {
				$this->Session->setFlash(__('The ftp group has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The ftp group could not be saved. Please, try again.', true));
			}
		}
	}

	function admin_edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid ftp group', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->FtpGroup->save($this->data)) {
				$this->Session->setFlash(__('The ftp group has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The ftp group could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->FtpGroup->read(null, $id);
		}
	}

	function admin_delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for ftp group', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->FtpGroup->delete($id)) {
			$this->Session->setFlash(__('Ftp group deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Ftp group was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
}
?>