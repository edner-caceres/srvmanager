<?php

class FtpUsersController extends AppController {

    var $name = 'FtpUsers';

    function index() {
        $this->FtpUser->recursive = 0;
        $this->set('ftpUsers', $this->paginate());
    }

    function view($id = null) {
        if (!$id) {
            $this->Session->setFlash(__('Invalid ftp user', true));
            $this->redirect(array('action' => 'index'));
        }
        $this->set('ftpUser', $this->FtpUser->read(null, $id));
    }

    function add() {
        if (!empty($this->data)) {
            if (!empty($this->data['FtpUser']['passwd'])) {

            }
            $this->FtpUser->create();
            if ($this->FtpUser->save($this->data)) {
                $pass_encrypt = $this->FtpUser->query("SELECT ENCRYPT('" . $this->data['FtpUser']['passwd'] . "') as password");
                $password = $pass_encrypt[0][0]['password'];
                $this->FtpUser->saveField('passwd', $password);
                $this->Session->setFlash(__('The ftp user has been saved', true));
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The ftp user could not be saved. Please, try again.', true));
            }
        }
        $ftpGroups = $this->FtpUser->FtpGroup->find('list');
        $this->set(compact('ftpGroups'));
    }

    function edit($id = null) {
        if (!$id && empty($this->data)) {
            $this->Session->setFlash(__('Invalid ftp user', true));
            $this->redirect(array('action' => 'index'));
        }
        if (!empty($this->data)) {
            if ($this->FtpUser->save($this->data)) {
                $this->Session->setFlash(__('The ftp user has been saved', true));
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The ftp user could not be saved. Please, try again.', true));
            }
        }
        if (empty($this->data)) {
            $this->data = $this->FtpUser->read(null, $id);
            $this->data['FtpUser']['passwd'] = '';
        }
        $ftpGroups = $this->FtpUser->FtpGroup->find('list');
        $this->set(compact('ftpGroups'));
    }

    function delete($id = null) {
        if (!$id) {
            $this->Session->setFlash(__('Invalid id for ftp user', true));
            $this->redirect(array('action' => 'index'));
        }
        if ($this->FtpUser->delete($id)) {
            $this->Session->setFlash(__('Ftp user deleted', true));
            $this->redirect(array('action' => 'index'));
        }
        $this->Session->setFlash(__('Ftp user was not deleted', true));
        $this->redirect(array('action' => 'index'));
    }

    function change_password($id = null) {
        if (!$id && empty($this->data)) {
            $this->Session->setFlash(__('Invalid ftp user', true));
            $this->redirect(array('action' => 'index'));
        }
        if (!empty($this->data)) {
            $pass_encrypt = $this->FtpUser->query("SELECT ENCRYPT('" . $this->data['FtpUser']['passwd'] . "') as password");
            $this->data['FtpUser']['passwd'] = $pass_encrypt[0][0]['password'];
            if ($this->FtpUser->save($this->data)) {
                $this->Session->setFlash(__('The ftp user has been saved', true));
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The ftp user could not be saved. Please, try again.', true));
            }
        }
        if (empty($this->data)) {
            $this->data = $this->FtpUser->read(null, $id);
            $this->data['FtpUser']['passwd'] = '';
        }
        $ftpGroups = $this->FtpUser->FtpGroup->find('list');
        $this->set(compact('ftpGroups'));
    }

    function admin_index() {
        $this->FtpUser->recursive = 0;
        $this->set('ftpUsers', $this->paginate());
    }

    function admin_view($id = null) {
        if (!$id) {
            $this->Session->setFlash(__('Invalid ftp user', true));
            $this->redirect(array('action' => 'index'));
        }
        $this->set('ftpUser', $this->FtpUser->read(null, $id));
    }

    function admin_add() {
        if (!empty($this->data)) {
            $this->FtpUser->create();
            if ($this->FtpUser->save($this->data)) {
                $this->Session->setFlash(__('The ftp user has been saved', true));
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The ftp user could not be saved. Please, try again.', true));
            }
        }
        $ftpGroups = $this->FtpUser->FtpGroup->find('list');
        $this->set(compact('ftpGroups'));
    }

    function admin_edit($id = null) {
        if (!$id && empty($this->data)) {
            $this->Session->setFlash(__('Invalid ftp user', true));
            $this->redirect(array('action' => 'index'));
        }
        if (!empty($this->data)) {
            if ($this->FtpUser->save($this->data)) {
                $this->Session->setFlash(__('The ftp user has been saved', true));
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The ftp user could not be saved. Please, try again.', true));
            }
        }
        if (empty($this->data)) {
            $this->data = $this->FtpUser->read(null, $id);
        }
        $ftpGroups = $this->FtpUser->FtpGroup->find('list');
        $this->set(compact('ftpGroups'));
    }

    function admin_delete($id = null) {
        if (!$id) {
            $this->Session->setFlash(__('Invalid id for ftp user', true));
            $this->redirect(array('action' => 'index'));
        }
        if ($this->FtpUser->delete($id)) {
            $this->Session->setFlash(__('Ftp user deleted', true));
            $this->redirect(array('action' => 'index'));
        }
        $this->Session->setFlash(__('Ftp user was not deleted', true));
        $this->redirect(array('action' => 'index'));
    }

}

?>